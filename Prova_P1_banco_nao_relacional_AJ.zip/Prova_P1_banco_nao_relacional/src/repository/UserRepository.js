const User = require('../models/User');

class UserRepository {
    async findAll() {
      return User.find();
    }
  
    async create(data) {
        const novoUsuario =  new User(data);
        return novoUsuario.save();
    }

    async login(email, password){
      const user = await User.findOne({email, password});
      return user 

    }

  }
  
  module.exports = new UserRepository();