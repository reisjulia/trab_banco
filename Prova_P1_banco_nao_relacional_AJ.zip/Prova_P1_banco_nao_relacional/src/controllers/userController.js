const UserRepository = require('../repository/UserRepository');

class UserController{
    async getAllUsers(req, res) {
        try {
            const users = await UserRepository.findAll();
            res.status(200).json(users);
        }
        catch (error) {
            res.status(400).json({ message: error.message });
        }
    };

    async create(req, res) {
        try {
            console.log(req.body)
            const newUser = await UserRepository.create(req.body);
            res.status(201).json(newUser);
        }
        catch (error) {
            res.status(400).json({ message: error.message });
        }
    };

    async login(req, res){
        try {
            const {email, password} = req.body;
            const user = await UserRepository.login(email, password);
            return res.status(200).json(user)
        }
        catch (error) {
            res.status(500).json({message: error.message})
        }
    }
}

module.exports = new UserController;