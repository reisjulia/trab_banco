const express = require('express');
const userController = require('../controllers/userController');

const userRouter = express.Router();

userRouter.post('/alpha', userController.create)
userRouter.get('/list', userController.getAllUsers)
userRouter.post('/login', userController.login)


module.exports = userRouter;