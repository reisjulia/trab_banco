const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors')

const app = express();
const PORT = 3000;
const path = require('path');
const bodyParser = require('body-parser');
const userRouter = require('./routes/userRoutes');
app.use(express.json());
app.use(cors());

const mongoURI = 'mongodb+srv://juliareisrodrigues5:123@cluster0.9vj78v4.mongodb.net/teste?retryWrites=true&w=majority&appName=Cluster0';

app.use(express.static(path.join(__dirname,'public')));

mongoose.connect(mongoURI, {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => console.log('MongoDB rodando'))
    .catch(err => console.log(err));

app.get('/cadastro_pac', (req, res) => { 
    res.sendFile(path.join(__dirname, 'public', 'views', 'cadastro_pac.html'));
});

app.get('/bemvindo', (req, res) => { 
    res.sendFile(path.join(__dirname, 'public','views', 'bemvindo.html'));
});

app.use(bodyParser.urlencoded({ extended: true }));
userRouter.get('/login_alpha', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'views', 'login.html'))
});

app.use('/users', userRouter)


app.listen(PORT,()=> {
    console.log(`Está rodando na porta ${PORT}`);
});




